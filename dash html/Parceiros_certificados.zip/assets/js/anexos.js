
// Função para baixar anexo via API Sankhya
function baixarAnexo(codParc, sequencia) {
    console.log("Iniciando download...", codParc, sequencia);
    
    // Mostrar loading
    const botao = event.target;
    const textoOriginal = botao.innerHTML;
    botao.innerHTML = '<i class="bi bi-hourglass-split me-1"></i>Baixando...';
    botao.disabled = true;
    
    try {
        // 1. Configurações
        const nomeTabela = 'AD_CERTIFICADOS';
        const nomeColuna = 'ANEXO';
        const nomeArquivo = `certificado_${codParc}_${sequencia}.pdf`;
        
        // 2. Criar JSON da chave primária
        const pkValues = {
            "CODPARC": codParc,
            "SEQUENCIA": sequencia
        };
        
        // 3. Codificar para URL
        const pkValuesEncoded = encodeURIComponent(JSON.stringify(pkValues));
        
        // 4. Montar URL de download
        const urlDownload = `/mge/download.mge?fileName=sab://${nomeColuna}&downloadFileName=${nomeArquivo}&pkValues=${pkValuesEncoded}&tableName=${nomeTabela}`;
        
        console.log("URL gerada:", urlDownload);
        
        // 5. Criar link invisível para download
        const linkDownload = document.createElement('a');
        linkDownload.href = urlDownload;
        linkDownload.target = '_blank'; // Abre em nova aba
        linkDownload.download = nomeArquivo;
        linkDownload.style.display = 'none';
        
        // 6. Adicionar à página e clicar
        document.body.appendChild(linkDownload);
        linkDownload.click();
        document.body.removeChild(linkDownload);
        
        console.log("Download iniciado com sucesso!");
        
    } catch (error) {
        console.error("Erro ao baixar:", error);
        alert('Erro ao baixar arquivo: ' + error.message);
    } finally {
        // Restaurar botão após 2 segundos
        setTimeout(() => {
            botao.innerHTML = textoOriginal;
            botao.disabled = false;
        }, 2000);
    }
}
