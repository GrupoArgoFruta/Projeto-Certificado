// contador.js

// Função para converter dados do JSP para JavaScript
function converterDadosJSP(dadosJSP) {
    return {
        rows: dadosJSP.map(cert => ({
            CODPARC: cert.CODPARC || '',
            CULTIVAR1: cert.CULTIVAR1 || '',
            CULTIVAR2: cert.CULTIVAR2 || '',
            CULTIVAR3: cert.CULTIVAR3 || ''
        }))
    };
}

// Função para obter todos os cultivares únicos de um parceiro
function obterCultivaresUnicos(parceiroId, dadosCompletos) {
    const cultivaresSet = new Set();
    
    if (!dadosCompletos || !dadosCompletos.rows) {
        console.error('Dados completos não disponíveis');
        return '';
    }
    
    dadosCompletos.rows.forEach(cert => {
        if (cert.CODPARC === parceiroId) {
            if (cert.CULTIVAR1 && cert.CULTIVAR1.trim() !== '' && cert.CULTIVAR1 !== 'null') {
                cultivaresSet.add(cert.CULTIVAR1.trim());
            }
            if (cert.CULTIVAR2 && cert.CULTIVAR2.trim() !== '' && cert.CULTIVAR2 !== 'null') {
                cultivaresSet.add(cert.CULTIVAR2.trim());
            }
            if (cert.CULTIVAR3 && cert.CULTIVAR3.trim() !== '' && cert.CULTIVAR3 !== 'null') {
                cultivaresSet.add(cert.CULTIVAR3.trim());
            }
        }
    });
    
    return Array.from(cultivaresSet).join(',');
}

// Função para inicializar todos os cultivares
function inicializarTodosCultivares(dadosJSP) {
    // Converte os dados do JSP para JavaScript
    window.dadosCompletosJS = converterDadosJSP(dadosJSP);
    
    const cards = document.querySelectorAll('.card.card-custom.paginated-item');
    
    cards.forEach(card => {
        const parceiroId = card.getAttribute('data-parceiro-id');
        const cultivaresElement = card.querySelector('.cultivares-text');
        
        if (cultivaresElement) {
            const cultivares = obterCultivaresUnicos(parceiroId, window.dadosCompletosJS);
            cultivaresElement.textContent = cultivares ? cultivares.replace(/,/g, ', ') : '-';
            card.setAttribute('data-cultivares', cultivares);
        }
    });
    
    console.log('Cultivares inicializados para', cards.length, 'parceiros');
    atualizarContadorParceiros();
}

// Função para atualizar contador
function atualizarContadorParceiros() {
    const totalParceiros = document.querySelectorAll('.card.card-custom.paginated-item').length;
    const contadorElement = document.getElementById('contadorParceiros');
    const totalRecordsElement = document.getElementById('totalRecords');
    
    if (contadorElement) contadorElement.textContent = totalParceiros;
    if (totalRecordsElement) totalRecordsElement.textContent = totalParceiros;
}