// Função para limpar o filtro
function limparFiltro() {
    document.getElementById('CULTIVAR_FILTER').selectedIndex = -1;
    document.getElementById('filterForm').submit();
}

// Função para aplicar filtro via JavaScript (opcional)
function aplicarFiltroJavaScript() {
    const cultivaresSelecionados = Array.from(document.getElementById('CULTIVAR_FILTER').selectedOptions)
        .map(option => option.value);
    
    // Se não há cultivares selecionados, recarrega a página sem filtros
    if (cultivaresSelecionados.length === 0) {
        window.location.href = window.location.pathname;
        return;
    }
    
   
    // Por enquanto vamos usar o submit do formulário
    document.getElementById('filterForm').submit();
}

// Atualizar contador de parceiros quando a página carregar
document.addEventListener('DOMContentLoaded', function() {
    atualizarContadorParceiros();
    
    // Manter os cultivares selecionados após o submit
    manterCultivaresSelecionados();
});

// Função para atualizar contador de parceiros
function atualizarContadorParceiros() {
    const totalParceiros = document.querySelectorAll('.card.card-custom.paginated-item').length;
    document.getElementById('contadorParceiros').textContent = totalParceiros;
    document.getElementById('totalRecords').textContent = totalParceiros;
}

// Função para manter os cultivares selecionados após o submit
function manterCultivaresSelecionados() {
    const urlParams = new URLSearchParams(window.location.search);
    const cultivaresParam = urlParams.get('CULTIVAR_FILTER');
    
    if (cultivaresParam) {
        const cultivares = cultivaresParam.split(',');
        const select = document.getElementById('CULTIVAR_FILTER');
        
        cultivares.forEach(cultivar => {
            for (let i = 0; i < select.options.length; i++) {
                if (select.options[i].value === cultivar) {
                    select.options[i].selected = true;
                    break;
                }
            }
        });
    }
}

// Função para filtrar cards por cultivares (via JavaScript - opcional)
function filtrarCardsPorCultivar(cultivares) {
    const cards = document.querySelectorAll('.card.card-custom.paginated-item');
    let totalVisiveis = 0;
    
    cards.forEach(card => {
        const cardCultivares = card.getAttribute('data-cultivares');
        let deveMostrar = false;
        
        if (cultivares.length === 0) {
            // Se não há filtro, mostra todos
            deveMostrar = true;
        } else if (cardCultivares) {
            // Verifica se o card tem pelo menos um dos cultivares selecionados
            const cultivaresCard = cardCultivares.split(',');
            deveMostrar = cultivares.some(cult => cultivaresCard.includes(cult));
        }
        
        if (deveMostrar) {
            card.style.display = 'block';
            totalVisiveis++;
        } else {
            card.style.display = 'none';
        }
    });
    
    document.getElementById('contadorParceiros').textContent = totalVisiveis;
    document.getElementById('totalRecords').textContent = totalVisiveis;
}

// Adicionar event listener para o formulário
document.getElementById('filterForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const cultivaresSelecionados = Array.from(document.getElementById('CULTIVAR_FILTER').selectedOptions)
        .map(option => option.value);
    
   
    // filtrarCardsPorCultivar(cultivaresSelecionados);
    
    // Por enquanto, vamos recarregar a página com os parâmetros
    this.submit();
});