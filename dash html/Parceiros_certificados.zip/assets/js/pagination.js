 class CardsPaginator {
        constructor(containerId, itemsPerPageSelectId, paginationId, pageInfoId, totalRecordsId) {
            this.container = document.getElementById(containerId);
            this.itemsPerPageSelect = document.getElementById(itemsPerPageSelectId);
            this.pagination = document.getElementById(paginationId);
            this.pageInfo = document.getElementById(pageInfoId);
            this.totalRecords = document.getElementById(totalRecordsId);
            
            this.currentPage = 1;
            this.itemsPerPage = 10;
            this.allCards = Array.from(this.container.querySelectorAll('.paginated-item'));
            this.filteredCards = this.allCards;
            
            this.init();
        }
        
        init() {
            // Configurar evento do seletor de itens por página
            this.itemsPerPageSelect.addEventListener('change', (e) => {
                this.itemsPerPage = parseInt(e.target.value);
                this.currentPage = 1;
                this.updateDisplay();
            });
            
            // Inicializar contadores
            this.updateCounters();
            this.updateDisplay();
        }
        
        updateCounters() {
            const totalRecords = this.allCards.length;
            this.totalRecords.textContent = totalRecords;
        }
        
        updateDisplay() {
            const startIndex = (this.currentPage - 1) * this.itemsPerPage;
            const endIndex = startIndex + this.itemsPerPage;
            
            // Esconder todos os cards
            this.allCards.forEach(card => card.style.display = 'none');
            
            // Mostrar apenas os cards da página atual
            const currentPageCards = this.filteredCards.slice(startIndex, endIndex);
            currentPageCards.forEach(card => card.style.display = 'block');
            
            this.updatePagination();
            this.updatePageInfo();
        }
        
        updatePageInfo() {
            const totalPages = Math.ceil(this.filteredCards.length / this.itemsPerPage);
            const startItem = ((this.currentPage - 1) * this.itemsPerPage) + 1;
            const endItem = Math.min(this.currentPage * this.itemsPerPage, this.filteredCards.length);
            
            if (this.filteredCards.length === 0) {
                this.pageInfo.textContent = 'Nenhum parceiro encontrado';
            } else {
                this.pageInfo.textContent = 
                    `Mostrando ${startItem} a ${endItem} de ${this.filteredCards.length} parceiros (Página ${this.currentPage} de ${totalPages})`;
            }
        }
        
        updatePagination() {
            const totalPages = Math.ceil(this.filteredCards.length / this.itemsPerPage);
            this.pagination.innerHTML = '';
            
            if (totalPages <= 1) return;
            
            // Botão Anterior
            const prevLi = this.createPaginationItem('Anterior', this.currentPage - 1, this.currentPage === 1);
            this.pagination.appendChild(prevLi);
            
            // Páginas
            const maxVisiblePages = 5;
            let startPage = Math.max(1, this.currentPage - Math.floor(maxVisiblePages / 2));
            let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
            
            if (endPage - startPage + 1 < maxVisiblePages) {
                startPage = Math.max(1, endPage - maxVisiblePages + 1);
            }
            
            // Primeira página
            if (startPage > 1) {
                this.pagination.appendChild(this.createPaginationItem('1', 1));
                if (startPage > 2) {
                    this.pagination.appendChild(this.createPaginationItem('...', null, true, true));
                }
            }
            
            // Páginas numeradas
            for (let i = startPage; i <= endPage; i++) {
                this.pagination.appendChild(this.createPaginationItem(i.toString(), i, false, false, i === this.currentPage));
            }
            
            // Última página
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                    this.pagination.appendChild(this.createPaginationItem('...', null, true, true));
                }
                this.pagination.appendChild(this.createPaginationItem(totalPages.toString(), totalPages));
            }
            
            // Botão Próximo
            const nextLi = this.createPaginationItem('Próximo', this.currentPage + 1, this.currentPage === totalPages);
            this.pagination.appendChild(nextLi);
        }
        
        createPaginationItem(text, page, disabled = false, ellipsis = false, active = false) {
            const li = document.createElement('li');
            li.className = 'page-item';
            
            if (disabled) li.classList.add('disabled');
            if (active) li.classList.add('active');
            if (ellipsis) li.classList.add('ellipsis');
            
            const a = document.createElement('a');
            a.className = 'page-link';
            a.href = '#';
            a.innerHTML = text;
            
            if (!disabled && !ellipsis && page !== null) {
                a.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.goToPage(page);
                });
            }
            
            li.appendChild(a);
            return li;
        }
        
        goToPage(page) {
            this.currentPage = page;
            this.updateDisplay();
            // Rolagem suave para o topo dos cards
            this.container.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }

    // Inicializar a paginação quando o documento carregar
    document.addEventListener('DOMContentLoaded', function() {
        new CardsPaginator(
            'cardsContainer',        // ID do container dos cards
            'itemsPerPage',          // ID do select de itens por página
            'pagination',            // ID do elemento de paginação
            'pageInfo',              // ID do elemento de informações da página
            'totalRecords'           // ID do elemento de total de registros
        );
    });