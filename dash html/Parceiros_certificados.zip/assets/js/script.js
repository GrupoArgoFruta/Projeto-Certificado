 $(document).ready(function() {
            // Efeito de hover nas linhas da tabela
            $('.table-custom tbody tr').hover(
                function() {
                    $(this).addClass('table-active');
                },
                function() {
                    $(this).removeClass('table-active');
                }
            );
            
            // Animação do ícone de collapse
            $('.card-header-custom').on('click', function() {
                $(this).toggleClass('collapsed');
            });
            
            // Fecha todos os cards ao carregar a página
            $('.collapse').removeClass('show');
        });